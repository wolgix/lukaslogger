Locales['nl'] = {
    ['updating_information'] = '[%s] Spelersinformatie aan het bijwerken....',
    ['waiting_information'] = '[%s] Wachten op databaseverbinding....',
    ['updated_information'] = '[%s] Spelersinformatie bijgewerkt....'
}