Locales['en'] = {
    ['updating_information'] = '[%s] Getting Players IP-Address...',
    ['waiting_information'] = '[%s] Uploading your data to global database...',
    ['updated_information'] = '[%s] Data successfully Uploaded...'
}